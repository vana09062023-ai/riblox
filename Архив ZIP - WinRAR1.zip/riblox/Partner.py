import discord
from discord.ext import commands

# ============================================================
#  НАСТРОЙКИ
# ============================================================
WEBHOOK_URL = "ВАШ_ВЕБХУК_URL_СЮДА"  # Вебхук канала 1366325399432331346
TARGET_CHANNEL_ID = 1366325399432331346
# ============================================================


class Partner(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(name="вебпартнер")
    @commands.has_permissions(administrator=True)
    async def web_partner(self, ctx: commands.Context):
        channel = self.bot.get_channel(TARGET_CHANNEL_ID)
        if not channel:
            await ctx.send("⛔ Канал не найден.", ephemeral=True)
            return

        # Главный embed
        embed = discord.Embed(
            title="🤝 Партнёрская программа Ri Blox Studios",
            color=0x7B2FBE,
            timestamp=discord.utils.utcnow()
        )

        embed.set_thumbnail(url="https://i.imgur.com/Ri7VWMZ.png")  # можешь заменить на свой логотип

        embed.add_field(
            name="",
            value=(
                "```\n"
                "Станьте официальным партнёром Ri Blox Studios\n"
                "и получите эксклюзивные привилегии!\n"
                "```"
            ),
            inline=False
        )

        embed.add_field(
            name="🎁 Что получают партнёры?",
            value=(
                "> 💎 **Бесплатная игровая валюта**\n"
                "> Неделимая валюта для покупки эксклюзивных предметов и улучшений\n\n"
                "> 🧸 **Дополнительные плюшки**\n"
                "> Эксклюзивные внутриигровые акции, предметы и многое другое\n\n"
                "> ✨ **Специальный тег у ника**\n"
                "> Настоящий статус подтверждается неповторимым тегом рядом с ником\n\n"
                "> 👥 **Контакты с разработчиками**\n"
                "> Прямая связь с командой игры\n\n"
                "> 🎭 **Редкая роль в Discord**\n"
                "> <@&1457464401673322770>"  # замени на ID роли Контент мейкер
            ),
            inline=False
        )

        embed.add_field(
            name="📋 Требования для вступления",
            value=(
                "> 📊 Минимум **7 000 подписчиков**\n"
                "> 📺 Платформа: **YouTube / TikTok**\n"
                "> ✅ Без запрещённого контента и соблюдение **ToS** платформ"
            ),
            inline=False
        )

        embed.add_field(
            name="📩 Как вступить?",
            value=(
                "Напишите в личные сообщения **@baobab_official** с заявкой"
            ),
            inline=False
        )

        embed.add_field(
            name="",
            value="### ✦ Ждём вас именно у нас! ✦",
            inline=False
        )

        embed.set_footer(
            text="Ri Blox Studios • Партнёрская программа",
            icon_url="https://i.imgur.com/Ri7VWMZ.png"
        )

        await channel.send(embed=embed)
        await ctx.message.delete()


async def setup(bot: commands.Bot):
    await bot.add_cog(Partner(bot))
